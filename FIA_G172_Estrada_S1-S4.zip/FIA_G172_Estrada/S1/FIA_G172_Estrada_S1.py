"""
Fundamentos de Inteligencia Artificial - Actividad Parcial 2 - Seccion 1
Aplicaciones y casos de estudio de IA: tabla comparativa e infografia
Alumno: Estrada Hernandez Alejandro | Grupo 172 | Politecnica de Atlautla

Genera: figuras/infografia_S1.png y figuras/tabla_comparativa_S1.csv
Uso:  python FIA_G172_Estrada_S1.py      (requiere: matplotlib)
"""
import csv
import os
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

CARPETA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figuras")
os.makedirs(CARPETA, exist_ok=True)

# Datos de los 3 casos (todas las cifras provienen de las fuentes citadas en el reporte)
CASOS = [
    {"id": "Caso 1", "nombre": "Detección de retinopatía diabética", "organizacion": "Google Research",
     "sector": "Salud", "rama": "Aprendizaje profundo / visión por computadora",
     "tecnica": "Red neuronal convolucional profunda sobre imágenes de fondo de ojo",
     "kpi": "Sensibilidad y especificidad", "cifra": "97.5 %", "cifra_txt": "sensibilidad (con 93.4 % de especificidad)",
     "país": "EE. UU.", "fuente": "Gulshan et al. (2016), JAMA", "color": "#2a9d8f"},
    {"id": "Caso 2", "nombre": "Mantenimiento predictivo Senseye", "organizacion": "Siemens",
     "sector": "Industria (manufactura)", "rama": "Aprendizaje automático (ML) sobre datos de sensores",
     "tecnica": "Modelos de ML para anticipar fallas y vida útil remanente de máquinas",
     "kpi": "Paros no planeados y productividad de mantenimiento", "cifra": "hasta 50 %",
     "cifra_txt": "menos paros no planeados (dato del proveedor)",
     "país": "Alemania / Reino Unido", "fuente": "Siemens (2022)", "color": "#c99700"},
    {"id": "Caso 3", "nombre": "Estimación de tiempo de llegada (ETA)", "organizacion": "Google Maps",
     "sector": "Movilidad", "rama": "Aprendizaje profundo sobre grafos (GNN)",
     "tecnica": "Red neuronal de grafos sobre segmentos de la red vial",
     "kpi": "ETAs con resultado negativo (error grande)", "cifra": "+40 %",
     "cifra_txt": "menos ETAs negativos (p. ej. en Sídney)",
     "país": "EE. UU. / Reino Unido", "fuente": "Derrow-Pinion et al. (2021), CIKM", "color": "#e76f51"},
]


def guardar_csv():
    campos = ["id", "nombre", "organizacion", "sector", "rama", "tecnica", "kpi", "cifra", "cifra_txt", "país", "fuente"]
    with open(os.path.join(CARPETA, "tabla_comparativa_S1.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=campos, extrasaction="ignore")
        w.writeheader()
        w.writerows(CASOS)


def infografia():
    fig = plt.figure(figsize=(11, 6.8))
    fig.patch.set_facecolor("#f7f9fb")
    fig.text(0.5, 0.945, "Tres casos reales de IA: salud, industria y movilidad", ha="center",
             fontsize=17, fontweight="bold", color="#1d3557")
    fig.text(0.5, 0.895, "Cifras reportadas por las fuentes; las métricas no son directamente comparables entre sí",
             ha="center", fontsize=9.5, color="#555")
    ancho, x0 = 0.30, 0.03
    for i, c in enumerate(CASOS):
        x = x0 + i * (ancho + 0.025)
        ax = fig.add_axes([x, 0.05, ancho, 0.81])
        ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
        ax.add_patch(FancyBboxPatch((0, 0), 1, 1, boxstyle="round,pad=0.0,rounding_size=0.04",
                                    fc="white", ec=c["color"], lw=3))
        ax.add_patch(FancyBboxPatch((0, 0.86), 1, 0.14, boxstyle="round,pad=0.0,rounding_size=0.04",
                                    fc=c["color"], ec=c["color"]))
        ax.text(0.5, 0.93, f'{c["id"]} | {c["sector"]}', ha="center", va="center", fontsize=11,
                fontweight="bold", color="white")
        ax.text(0.5, 0.795, "\n".join(textwrap.wrap(c["nombre"], 30)), ha="center", va="center", fontsize=10.5,
                fontweight="bold", color="#1d3557")
        ax.text(0.5, 0.725, c["organizacion"], ha="center", va="center", fontsize=9, color="#555")
        ax.text(0.5, 0.645, c["cifra"], ha="center", va="center", fontsize=30, fontweight="bold", color=c["color"])
        ax.text(0.5, 0.555, "\n".join(textwrap.wrap(c["cifra_txt"], 38)), ha="center", va="center", fontsize=8.3, color="#333")
        filas = [("Rama de IA", c["rama"]), ("Técnica", c["tecnica"]), ("KPI", c["kpi"]), ("País", c["país"])]
        y = 0.47
        for etiqueta, valor in filas:
            ax.text(0.05, y, etiqueta.upper(), fontsize=7, fontweight="bold", color=c["color"], va="top")
            texto = "\n".join(textwrap.wrap(valor, 40))
            ax.text(0.05, y - 0.028, texto, fontsize=8, color="#222", va="top", linespacing=1.15)
            y -= 0.055 + 0.03 * len(textwrap.wrap(valor, 40))
        ax.text(0.5, 0.02, "Fuente: " + c["fuente"], ha="center", fontsize=7.5, style="italic", color="#666")
    fig.savefig(os.path.join(CARPETA, "infografia_S1.png"), dpi=200)
    plt.close(fig)


if __name__ == "__main__":
    guardar_csv()
    infografia()
    print("Archivos generados en", CARPETA)
