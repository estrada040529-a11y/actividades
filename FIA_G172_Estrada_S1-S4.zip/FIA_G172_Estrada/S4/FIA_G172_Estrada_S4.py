"""
Fundamentos de Inteligencia Artificial - Actividad Parcial 2 - Seccion 4
Busqueda ciega: BFS vs DFS para resolver laberintos
Alumno: Estrada Hernandez Alejandro | Grupo 172 | Politecnica de Atlautla

Problema: encontrar un camino de la entrada (esquina superior izquierda) a la salida
(esquina inferior derecha) de un laberinto en cuadricula. Estado = celda (fila, columna);
acciones = moverse a una celda libre vecina; costo = 1 por movimiento.
Los laberintos se generan con "backtracker" y se les abren pasillos extra (ciclos), de modo
que existan varios caminos y BFS y DFS puedan diferir.

Uso:  python FIA_G172_Estrada_S4.py      (requiere: numpy, matplotlib)
Salida: figuras/laberinto_S4.png, figuras/comparativa_S4.png, figuras/resultados_S4.json
"""
import json
import os
import random
import time
from collections import deque

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

CARPETA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figuras")
os.makedirs(CARPETA, exist_ok=True)

# Orden fijo de las acciones (derecha, abajo, izquierda, arriba) para ambos algoritmos
MOVS = [(0, 1), (1, 0), (0, -1), (-1, 0)]


# ----------------------------------------------------------------------------
# Generacion del laberinto (1 = pared, 0 = libre). Matriz de (2n+1) x (2n+1).
# ----------------------------------------------------------------------------
def generar_laberinto(n, semilla, p_extra=0.10):
    rnd = random.Random(semilla)
    t = 2 * n + 1
    lab = [[1] * t for _ in range(t)]
    lab[1][1] = 0
    pila = [(1, 1)]
    while pila:                                   # backtracker iterativo
        f, c = pila[-1]
        vec = [(f + 2 * df, c + 2 * dc, f + df, c + dc) for df, dc in MOVS
               if 0 < f + 2 * df < t - 1 and 0 < c + 2 * dc < t - 1 and lab[f + 2 * df][c + 2 * dc] == 1]
        if vec:
            nf, nc, pf, pc = rnd.choice(vec)
            lab[pf][pc] = 0
            lab[nf][nc] = 0
            pila.append((nf, nc))
        else:
            pila.pop()
    # abrir paredes interiores que separan dos pasillos -> crea ciclos (varios caminos)
    for f in range(1, t - 1):
        for c in range(1, t - 1):
            if lab[f][c] == 1 and rnd.random() < p_extra:
                if (lab[f - 1][c] == 0 and lab[f + 1][c] == 0) or (lab[f][c - 1] == 0 and lab[f][c + 1] == 0):
                    lab[f][c] = 0
    return lab


def vecinos(lab, celda):
    f, c = celda
    for df, dc in MOVS:
        nf, nc = f + df, c + dc
        if 0 <= nf < len(lab) and 0 <= nc < len(lab[0]) and lab[nf][nc] == 0:
            yield (nf, nc)


def reconstruir(padre, meta):
    camino = []
    while meta is not None:
        camino.append(meta)
        meta = padre[meta]
    return camino[::-1]


# ----------------------------------------------------------------------------
# BFS: cola FIFO. Garantiza el camino con menos pasos (completo y optimo, costo uniforme).
# ----------------------------------------------------------------------------
def bfs(lab, inicio, meta):
    frontera = deque([inicio])
    padre = {inicio: None}
    expandidos, orden, max_frontera = 0, [], 1
    while frontera:
        actual = frontera.popleft()
        expandidos += 1
        orden.append(actual)
        if actual == meta:
            return reconstruir(padre, meta), expandidos, max_frontera, orden
        for v in vecinos(lab, actual):
            if v not in padre:
                padre[v] = actual
                frontera.append(v)
        max_frontera = max(max_frontera, len(frontera))
    return None, expandidos, max_frontera, orden


# ----------------------------------------------------------------------------
# DFS: pila LIFO. Completo en grafos finitos con control de repetidos, pero NO optimo.
# ----------------------------------------------------------------------------
def dfs(lab, inicio, meta):
    pila = [(inicio, None)]
    padre, visitados = {}, set()
    expandidos, orden, max_frontera = 0, [], 1
    while pila:
        actual, anterior = pila.pop()
        if actual in visitados:
            continue
        visitados.add(actual)
        padre[actual] = anterior
        expandidos += 1
        orden.append(actual)
        if actual == meta:
            return reconstruir(padre, meta), expandidos, max_frontera, orden
        for v in reversed(list(vecinos(lab, actual))):    # reversed: respeta el orden de MOVS
            if v not in visitados:
                pila.append((v, actual))
        max_frontera = max(max_frontera, len(pila))
    return None, expandidos, max_frontera, orden


def medir(algoritmo, lab, inicio, meta, repeticiones=20):
    """Devuelve metricas; el tiempo es el minimo de varias repeticiones (ms)."""
    mejor_t = float("inf")
    for _ in range(repeticiones):
        t0 = time.perf_counter()
        camino, exp, front, orden = algoritmo(lab, inicio, meta)
        mejor_t = min(mejor_t, time.perf_counter() - t0)
    return {"longitud_camino": len(camino) - 1, "nodos_expandidos": exp,
            "max_frontera": front, "tiempo_ms": mejor_t * 1000.0}, camino, orden


def dibujar(lab, camino, orden, ax, titulo):
    img = np.array(lab, dtype=float)
    ax.imshow(img, cmap="Greys", vmin=0, vmax=1.6)
    if orden:
        o = np.array(orden)
        ax.scatter(o[:, 1], o[:, 0], s=5, color="#6baed6", alpha=0.55, marker="s")
    c = np.array(camino)
    ax.plot(c[:, 1], c[:, 0], color="#d62728", lw=2)
    ax.plot(*camino[0][::-1], "o", color="#2ca02c", ms=7)
    ax.plot(*camino[-1][::-1], "*", color="#ff7f0e", ms=12)
    ax.set_title(titulo, fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])


def main():
    resultados = {"comparativa_por_tamano": {}}

    # ---- Caso ilustrativo: laberinto 15x15 celdas (matriz 31x31), semilla 7 ----
    n, semilla = 15, 7
    lab = generar_laberinto(n, semilla)
    ini, fin = (1, 1), (2 * n - 1, 2 * n - 1)
    m_bfs, cam_bfs, ord_bfs = medir(bfs, lab, ini, fin)
    m_dfs, cam_dfs, ord_dfs = medir(dfs, lab, ini, fin)
    resultados["caso_ilustrativo"] = {"tamano_celdas": n, "semilla": semilla, "BFS": m_bfs, "DFS": m_dfs,
                                      "celdas_libres": int(sum(1 for f in lab for v in f if v == 0))}
    fig, ejes = plt.subplots(1, 2, figsize=(11, 5.6))
    dibujar(lab, cam_bfs, ord_bfs, ejes[0],
            f"BFS: camino={m_bfs['longitud_camino']} pasos, expandidos={m_bfs['nodos_expandidos']}")
    dibujar(lab, cam_dfs, ord_dfs, ejes[1],
            f"DFS: camino={m_dfs['longitud_camino']} pasos, expandidos={m_dfs['nodos_expandidos']}")
    fig.suptitle("Laberinto 15x15 (verde=inicio, naranja=meta, azul=nodos expandidos, rojo=camino)", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(os.path.join(CARPETA, "laberinto_S4.png"), dpi=200)
    plt.close(fig)

    # ---- Experimento: 30 laberintos por cada tamano ----
    tamanos = [10, 15, 20, 30]
    for n in tamanos:
        filas = {"BFS": [], "DFS": []}
        for s in range(30):
            lab = generar_laberinto(n, s)
            ini, fin = (1, 1), (2 * n - 1, 2 * n - 1)
            for nombre, alg in (("BFS", bfs), ("DFS", dfs)):
                m, _, _ = medir(alg, lab, ini, fin, repeticiones=3)
                filas[nombre].append(m)
        resultados["comparativa_por_tamano"][str(n)] = {
            nombre: {k: round(float(np.mean([r[k] for r in filas[nombre]])), 2) for k in filas[nombre][0]}
            for nombre in filas}
        resultados["comparativa_por_tamano"][str(n)]["dfs_camino_mas_largo_pct"] = round(
            100.0 * (np.mean([r["longitud_camino"] for r in filas["DFS"]]) /
                     np.mean([r["longitud_camino"] for r in filas["BFS"]]) - 1.0), 1)
        resultados["comparativa_por_tamano"][str(n)]["dfs_gana_expandidos"] = int(sum(
            d["nodos_expandidos"] < b["nodos_expandidos"] for b, d in zip(filas["BFS"], filas["DFS"])))

    # ---- Grafica comparativa ----
    metricas = [("nodos_expandidos", "Nodos expandidos"), ("longitud_camino", "Longitud del camino (pasos)"),
                ("tiempo_ms", "Tiempo (ms)")]
    fig, ejes = plt.subplots(1, 3, figsize=(11.5, 3.8))
    x = np.arange(len(tamanos))
    for ax, (clave, nombre) in zip(ejes, metricas):
        for i, (alg, color) in enumerate((("BFS", "#1f77b4"), ("DFS", "#d62728"))):
            vals = [resultados["comparativa_por_tamano"][str(n)][alg][clave] for n in tamanos]
            ax.bar(x + (i - 0.5) * 0.38, vals, 0.38, color=color, label=alg)
        ax.set_xticks(x, [f"{n}x{n}" for n in tamanos])
        ax.set_title(nombre); ax.grid(axis="y", alpha=0.3); ax.legend()
    fig.suptitle("Promedio en 30 laberintos por tamano", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(CARPETA, "comparativa_S4.png"), dpi=200)
    plt.close(fig)

    with open(os.path.join(CARPETA, "resultados_S4.json"), "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2)
    print(json.dumps(resultados, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
