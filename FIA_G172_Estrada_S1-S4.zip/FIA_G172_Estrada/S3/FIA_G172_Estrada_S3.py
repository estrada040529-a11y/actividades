"""
Fundamentos de Inteligencia Artificial - Actividad Parcial 2 - Seccion 3
Busqueda local: Hill Climbing vs Simulated Annealing sobre la funcion de Rastrigin
Alumno: Estrada Hernandez Alejandro | Grupo 172 | Politecnica de Atlautla

Ambos algoritmos usan el mismo presupuesto: 20,000 evaluaciones de f(x) por corrida.
Problema: minimizar f(x) = 10n + sum(x_i^2 - 10 cos(2 pi x_i)),  x_i en [-5.12, 5.12]
  (funcion multimodal; minimo global f(0,...,0) = 0 y muchisimos minimos locales)

Uso:  python FIA_G172_Estrada_S3.py      (requiere: numpy, matplotlib)
Salida: figuras/convergencia_S3.png, figuras/trayectorias_S3.png, figuras/boxplot_S3.png,
        figuras/resultados_S3.json
"""
import json
import math
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

CARPETA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figuras")
os.makedirs(CARPETA, exist_ok=True)

LIM = 5.12          # dominio de cada variable
EVALS = 20000       # presupuesto de evaluaciones de f(x): IGUAL para ambos algoritmos (comparacion justa)
ETA = 0.50          # eta: desviacion estandar del paso gaussiano (tamano de vecindad)
K_VECINOS = 10      # vecinos evaluados por iteracion en Hill Climbing  -> 2000 iteraciones
ITERS_HC = EVALS // K_VECINOS
T0, T_FIN = 5.0, 0.01    # Simulated Annealing: temperatura inicial y final
ALFA = (T_FIN / T0) ** (1.0 / EVALS)   # factor de enfriamiento geometrico: T_k = T0 * ALFA^k
CORRIDAS = 30       # corridas independientes (semillas 0..29)


# ---------------------- funcion objetivo ----------------------
def rastrigin(x):
    """Funcion objetivo (costo) a MINIMIZAR."""
    x = np.asarray(x, dtype=float)
    return 10.0 * x.size + float(np.sum(x ** 2 - 10.0 * np.cos(2.0 * np.pi * x)))


def vecino(x, eta, rng):
    """Vecindad: perturbacion gaussiana N(0, eta^2) en cada coordenada, dentro del dominio."""
    return np.clip(x + rng.normal(0.0, eta, size=x.shape), -LIM, LIM)


# ---------------------- Hill Climbing ----------------------
def hill_climbing(dim, rng, iters=ITERS_HC, eta=ETA, k=K_VECINOS):
    """Ascenso (descenso) de colina: genera k vecinos y se mueve al mejor si mejora."""
    x = rng.uniform(-LIM, LIM, dim)
    fx = rastrigin(x)
    historial, ruta = [fx], [x.copy()]
    for _ in range(iters):
        candidatos = [vecino(x, eta, rng) for _ in range(k)]
        valores = [rastrigin(c) for c in candidatos]
        i = int(np.argmin(valores))
        if valores[i] < fx:                 # solo acepta mejoras
            x, fx = candidatos[i], valores[i]
        historial.append(fx)
        ruta.append(x.copy())
    return x, fx, np.array(historial), np.array(ruta)


# ---------------------- Simulated Annealing ----------------------
def simulated_annealing(dim, rng, iters=EVALS, eta=ETA, t0=T0, alfa=ALFA):
    """Recocido simulado: acepta empeoramientos con probabilidad exp(-delta/T); T = T0*alfa^k."""
    x = rng.uniform(-LIM, LIM, dim)
    fx = rastrigin(x)
    mejor_x, mejor_f = x.copy(), fx
    historial, ruta = [mejor_f], [x.copy()]
    t = t0
    for _ in range(iters):
        y = vecino(x, eta, rng)
        fy = rastrigin(y)
        delta = fy - fx
        if delta < 0 or rng.random() < math.exp(-delta / t):
            x, fx = y, fy
            if fx < mejor_f:
                mejor_x, mejor_f = x.copy(), fx
        t *= alfa                           # esquema de enfriamiento geometrico
        historial.append(mejor_f)           # se grafica la MEJOR solucion encontrada
        ruta.append(x.copy())
    return mejor_x, mejor_f, np.array(historial), np.array(ruta)


# ---------------------- experimento ----------------------
def experimento(dim):
    res = {"HC": [], "SA": []}
    hist = {"HC": [], "SA": []}
    for semilla in range(CORRIDAS):
        for nombre, algoritmo in (("HC", hill_climbing), ("SA", simulated_annealing)):
            rng = np.random.default_rng(semilla)
            _, f, h, _ = algoritmo(dim, rng)
            if nombre == "SA":
                h = h[::K_VECINOS]       # una muestra cada 10 evaluaciones -> mismo eje que HC
            res[nombre].append(f)
            hist[nombre].append(h)
    return res, {k: np.array(v) for k, v in hist.items()}


def resumen(valores, umbral=1e-2):
    v = np.array(valores)
    return {"media": round(float(v.mean()), 4), "desv_est": round(float(v.std(ddof=1)), 4),
            "mediana": round(float(np.median(v)), 4), "mejor": round(float(v.min()), 6),
            "peor": round(float(v.max()), 4), "pct_optimo_global": round(100.0 * float(np.mean(v < umbral)), 1)}


def main():
    salida = {"parametros": {"dominio": [-LIM, LIM], "evaluaciones_por_corrida": EVALS,
                             "iteraciones_HC": ITERS_HC, "iteraciones_SA": EVALS, "eta": ETA,
                             "vecinos_HC": K_VECINOS, "T0": T0, "T_final": T_FIN,
                             "alfa": round(ALFA, 7), "corridas": CORRIDAS}}
    hist2 = None
    for dim in (2, 5, 10):
        res, hist = experimento(dim)
        salida[f"n={dim}"] = {"HC": resumen(res["HC"]), "SA": resumen(res["SA"]),
                              "valores": {k: [round(x, 5) for x in v] for k, v in res.items()}}
        if dim == 2:
            hist2 = hist
            res2 = res

    # --- Figura 1: convergencia media (n=2) con banda p10-p90 ---
    fig, ejes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, escala in zip(ejes, ("linear", "log")):
        for nombre, color in (("HC", "#d62728"), ("SA", "#1f77b4")):
            h = hist2[nombre]
            it = np.arange(h.shape[1]) * K_VECINOS      # eje x = evaluaciones de f(x)
            ax.plot(it, h.mean(axis=0), color=color, lw=2,
                    label={"HC": "Hill Climbing", "SA": "Simulated Annealing"}[nombre] + " (media)")
            ax.fill_between(it, np.percentile(h, 10, axis=0), np.percentile(h, 90, axis=0), color=color, alpha=0.18)
        ax.set_xlabel("Evaluaciones de f(x)")
        ax.set_ylabel("Mejor f(x) encontrado")
        ax.set_title("Convergencia (n = 2, 30 corridas)" + (" - escala log" if escala == "log" else ""))
        ax.grid(alpha=0.3)
        if escala == "log":
            ax.set_yscale("symlog", linthresh=1e-3)
        ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(CARPETA, "convergencia_S3.png"), dpi=200)
    plt.close(fig)

    # --- Figura 2: trayectorias sobre las curvas de nivel (semilla 3) ---
    xs = np.linspace(-LIM, LIM, 400)
    X, Y = np.meshgrid(xs, xs)
    Z = 20 + X ** 2 + Y ** 2 - 10 * (np.cos(2 * np.pi * X) + np.cos(2 * np.pi * Y))
    fig, ejes = plt.subplots(1, 2, figsize=(11, 4.8))
    for ax, (nombre, alg) in zip(ejes, (("Hill Climbing", hill_climbing), ("Simulated Annealing", simulated_annealing))):
        rng = np.random.default_rng(3)
        xf, ff, _, ruta = alg(2, rng)
        cs = ax.contourf(X, Y, Z, levels=30, cmap="viridis", alpha=0.85)
        ax.plot(ruta[:, 0], ruta[:, 1], "w-", lw=0.6, alpha=0.7)
        ax.plot(*ruta[0], "o", color="#2ca02c", ms=9, mec="k", label="inicio")
        ax.plot(*xf, "*", color="#ff7f0e", ms=16, mec="k", label=f"mejor (f={ff:.3f})")
        ax.plot(0, 0, "x", color="red", ms=10, mew=2, label="optimo global")
        ax.set_title(f"{nombre} - trayectoria (semilla 3)")
        ax.set_xlabel("x1"); ax.set_ylabel("x2"); ax.legend(loc="upper right", fontsize=8)
    fig.colorbar(cs, ax=ejes, shrink=0.85, label="f(x)")
    fig.savefig(os.path.join(CARPETA, "trayectorias_S3.png"), dpi=200, bbox_inches="tight")
    plt.close(fig)

    # --- Figura 3: distribucion de resultados finales por dimension ---
    fig, ejes = plt.subplots(1, 3, figsize=(11, 3.8))
    for ax, dim in zip(ejes, (2, 5, 10)):
        v = salida[f"n={dim}"]["valores"]
        bp = ax.boxplot([v["HC"], v["SA"]], tick_labels=["Hill Climbing", "Simul. Annealing"], patch_artist=True)
        for caja, c in zip(bp["boxes"], ("#f4b6b6", "#a9cbea")):
            caja.set_facecolor(c)
        ax.set_title(f"n = {dim}")
        ax.set_ylabel("f(x) final")
        ax.grid(alpha=0.3)
    fig.suptitle("Valor final de f(x) en 30 corridas (menor es mejor)")
    fig.tight_layout()
    fig.savefig(os.path.join(CARPETA, "boxplot_S3.png"), dpi=200)
    plt.close(fig)

    with open(os.path.join(CARPETA, "resultados_S3.json"), "w", encoding="utf-8") as f:
        json.dump(salida, f, ensure_ascii=False, indent=2)
    for dim in (2, 5, 10):
        print(f"n={dim}", "HC:", salida[f"n={dim}"]["HC"], "\n     SA:", salida[f"n={dim}"]["SA"])
    print(salida["parametros"])


if __name__ == "__main__":
    main()
