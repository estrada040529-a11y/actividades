"""
Fundamentos de Inteligencia Artificial - Actividad Parcial 2 - Seccion 2
Modelado de problemas como problemas de busqueda + grafo de estados con NetworkX
Alumno: Estrada Hernandez Alejandro | Grupo 172 | Politecnica de Atlautla

Problemas modelados:
  A) Jarras de agua (4 L y 3 L; meta: 2 L en la jarra de 4 L)  -> grafo dirigido PONDERADO
  B) Misioneros y canibales (3 y 3, bote de 2 plazas)            -> grafo dirigido

Uso:  python FIA_G172_Estrada_S2.py      (requiere: networkx, matplotlib)
Salida: figuras/diagrama_S2_jarras.png, figuras/diagrama_S2_misioneros.png, figuras/resultados_S2.json
"""
import json
import os
from collections import deque

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx

CARPETA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figuras")
os.makedirs(CARPETA, exist_ok=True)


# ----------------------------------------------------------------------------
# 1. Interfaz comun de un problema de busqueda: (estado, acciones, costo, meta)
# ----------------------------------------------------------------------------
class ProblemaBusqueda:
    """Define un problema por su estado inicial, sus acciones y su prueba de meta."""

    def __init__(self, inicial, meta):
        self.inicial = inicial
        self.meta = meta

    def acciones(self, estado):
        """Devuelve una lista de tuplas (nombre_accion, estado_resultante, costo)."""
        raise NotImplementedError

    def es_meta(self, estado):
        return estado == self.meta if not callable(self.meta) else self.meta(estado)


# ----------------------------------------------------------------------------
# 2. Problema A: jarras de agua. Estado = (litros_en_A, litros_en_B)
#    Costo de una accion = litros de agua manipulados (llenar/vaciar/verter).
# ----------------------------------------------------------------------------
class Jarras(ProblemaBusqueda):
    def __init__(self, cap_a=4, cap_b=3, litros_meta=2):
        super().__init__((0, 0), lambda e: e[0] == litros_meta)
        self.ca, self.cb = cap_a, cap_b

    def acciones(self, estado):
        a, b = estado
        res = []
        if a < self.ca:
            res.append(("Llenar A", (self.ca, b), self.ca - a))
        if b < self.cb:
            res.append(("Llenar B", (a, self.cb), self.cb - b))
        if a > 0:
            res.append(("Vaciar A", (0, b), a))
        if b > 0:
            res.append(("Vaciar B", (a, 0), b))
        if a > 0 and b < self.cb:
            t = min(a, self.cb - b)
            res.append(("Verter A->B", (a - t, b + t), t))
        if b > 0 and a < self.ca:
            t = min(b, self.ca - a)
            res.append(("Verter B->A", (a + t, b - t), t))
        return res


# ----------------------------------------------------------------------------
# 3. Problema B: misioneros y canibales. Estado = (M_izq, C_izq, bote)
#    bote = 0 (orilla izquierda) o 1 (orilla derecha). Costo = 1 por cruce.
# ----------------------------------------------------------------------------
class MisionerosCanibales(ProblemaBusqueda):
    def __init__(self, n=3, capacidad_bote=2):
        super().__init__((n, n, 0), (0, 0, 1))
        self.n, self.cap = n, capacidad_bote

    def valido(self, m, c):
        """Ningun lado puede tener mas canibales que misioneros (si hay misioneros)."""
        if not (0 <= m <= self.n and 0 <= c <= self.n):
            return False
        mi, ci = self.n - m, self.n - c
        return (m == 0 or m >= c) and (mi == 0 or mi >= ci)

    def acciones(self, estado):
        m, c, b = estado
        res = []
        for dm in range(self.cap + 1):
            for dc in range(self.cap + 1 - dm):
                if dm + dc == 0:
                    continue
                if b == 0:   # el bote sale de la izquierda
                    nm, nc = m - dm, c - dc
                else:        # el bote regresa desde la derecha
                    nm, nc = m + dm, c + dc
                if self.valido(nm, nc):
                    res.append((f"Cruzan {dm}M,{dc}C", (nm, nc, 1 - b), 1))
        return res


# ----------------------------------------------------------------------------
# 4. Generador de estados y grafo dirigido/ponderado con NetworkX
# ----------------------------------------------------------------------------
def generar_grafo(problema):
    """Explora todos los estados alcanzables (BFS) y construye un DiGraph ponderado."""
    g = nx.DiGraph()
    g.add_node(problema.inicial)
    frontera, vistos = deque([problema.inicial]), {problema.inicial}
    while frontera:
        s = frontera.popleft()
        for accion, s2, costo in problema.acciones(s):
            g.add_edge(s, s2, accion=accion, weight=costo)
            if s2 not in vistos:
                vistos.add(s2)
                frontera.append(s2)
    return g


def analizar(nombre, problema, g):
    """Calcula metricas del espacio de estados y la solucion optima (Dijkstra)."""
    metas = [s for s in g.nodes if problema.es_meta(s)]
    mejor = min(metas, key=lambda s: nx.dijkstra_path_length(g, problema.inicial, s, weight="weight"))
    camino_costo = nx.dijkstra_path(g, problema.inicial, mejor, weight="weight")
    camino_pasos = nx.shortest_path(g, problema.inicial, mejor)  # minimo de acciones
    costo = nx.dijkstra_path_length(g, problema.inicial, mejor, weight="weight")
    b_prom = g.number_of_edges() / g.number_of_nodes()
    b_max = max(d for _, d in g.out_degree())
    acciones = [g[u][v]["accion"] for u, v in zip(camino_costo, camino_costo[1:])]
    return {
        "problema": nombre,
        "estados": g.number_of_nodes(),
        "transiciones": g.number_of_edges(),
        "metas": len(metas),
        "factor_ramificacion_promedio": round(b_prom, 2),
        "factor_ramificacion_maximo": b_max,
        "profundidad_solucion_pasos": len(camino_pasos) - 1,
        "costo_optimo": costo,
        "camino_optimo": [list(s) for s in camino_costo],
        "acciones_camino_optimo": acciones,
        "ciclos_dirigidos": not nx.is_directed_acyclic_graph(g),
        "componentes_fuertemente_conexas": nx.number_strongly_connected_components(g),
    }, camino_costo


# ----------------------------------------------------------------------------
# 5. Diagramas del grafo
# ----------------------------------------------------------------------------
def dibujar(g, pos, camino, titulo, archivo, etiquetas_aristas=False, tam=(11, 7.5), tam_nodo=900):
    fig, ax = plt.subplots(figsize=tam)
    en_camino = set(zip(camino, camino[1:]))
    aristas_c = [e for e in g.edges if e in en_camino]
    aristas_o = [e for e in g.edges if e not in en_camino]
    nx.draw_networkx_edges(g, pos, edgelist=aristas_o, ax=ax, edge_color="#9aa5b1", width=0.9,
                           arrows=True, arrowsize=11, node_size=tam_nodo,
                           connectionstyle="arc3,rad=0.12", alpha=0.8)
    nx.draw_networkx_edges(g, pos, edgelist=aristas_c, ax=ax, edge_color="#d62728", width=2.8,
                           arrows=True, arrowsize=16, node_size=tam_nodo,
                           connectionstyle="arc3,rad=0.12")
    colores = []
    for n in g.nodes:
        if n == camino[0]:
            colores.append("#2ca02c")
        elif n == camino[-1]:
            colores.append("#ff7f0e")
        elif n in camino:
            colores.append("#f6c3c3")
        else:
            colores.append("#dbe9f6")
    nx.draw_networkx_nodes(g, pos, ax=ax, node_color=colores, node_size=tam_nodo, edgecolors="#34495e")
    nx.draw_networkx_labels(g, pos, ax=ax, labels={n: "".join(map(str, n)) for n in g.nodes}, font_size=8)
    if etiquetas_aristas:
        nx.draw_networkx_edge_labels(g, pos, edge_labels={e: g.edges[e]["weight"] for e in aristas_c},
                                     font_size=7, font_color="#d62728", ax=ax, label_pos=0.35)
    ax.set_title(titulo, fontsize=12, fontweight="bold")
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(os.path.join(CARPETA, archivo), dpi=200)
    plt.close(fig)


def main():
    resultados = []

    # --- Problema A: Jarras (posicion de cada nodo = sus litros (A, B)) ---
    pa = Jarras()
    ga = generar_grafo(pa)
    ra, camino_a = analizar("Jarras de agua (4 L y 3 L, meta 2 L en A)", pa, ga)
    pos_a = {n: (n[0] * 2.0, n[1] * 2.0) for n in ga.nodes}
    dibujar(ga, pos_a, camino_a,
            "Grafo del espacio de estados: jarras (A,B).  Rojo = camino de costo minimo",
            "diagrama_S2_jarras.png", etiquetas_aristas=True, tam=(10, 7.5), tam_nodo=800)
    resultados.append(ra)

    # --- Problema B: Misioneros y canibales (dos paneles segun la orilla del bote) ---
    pb = MisionerosCanibales()
    gb = generar_grafo(pb)
    rb, camino_b = analizar("Misioneros y canibales (3M, 3C, bote de 2)", pb, gb)
    pos_b = {n: (n[1] * 1.6 + 6.5 * n[2], n[0] * 1.6) for n in gb.nodes}
    dibujar(gb, pos_b, camino_b,
            "Grafo de estados (M_izq, C_izq, bote). Izq: bote en la orilla izquierda | Der: en la derecha",
            "diagrama_S2_misioneros.png", etiquetas_aristas=False, tam=(12, 5.5), tam_nodo=700)
    resultados.append(rb)

    with open(os.path.join(CARPETA, "resultados_S2.json"), "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2)
    for r in resultados:
        print(json.dumps(r, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
