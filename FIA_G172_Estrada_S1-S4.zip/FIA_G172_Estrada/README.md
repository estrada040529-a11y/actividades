# Fundamentos de Inteligencia Artificial - Actividad Parcial 2

**Alumno:** Estrada Hernández Alejandro  |  **Grupo:** 172  |  **Cuatrimestre:** 7
**Universidad:** Politécnica de Atlautla  |  **Docente:** Mtro. Javier García Lara
**Periodo:** 12 al 26 de octubre de 2026

## Contenido

| Sección | Tema | Entrega (PDF) | Código |
|---|---|---|---|
| S1 | Aplicaciones y casos de estudio de la IA | `S1/FIA_G172_Estrada_S1.pdf` | `S1/FIA_G172_Estrada_S1.py` |
| S2 | Problemas y espacios de búsqueda (grafos con NetworkX) | `S2/FIA_G172_Estrada_S2.pdf` | `S2/FIA_G172_Estrada_S2.py` |
| S3 | Búsqueda local: Hill Climbing y Simulated Annealing | `S3/FIA_G172_Estrada_S3.pdf` | `S3/FIA_G172_Estrada_S3.py` |
| S4 | Búsqueda ciega: BFS y DFS en laberintos | `S4/FIA_G172_Estrada_S4.pdf` | `S4/FIA_G172_Estrada_S4.py` |

Cada carpeta incluye `figuras/` con las gráficas y diagramas generados por el script.

## Cómo reproducir los resultados

1. Instalar Python 3.9 o superior.
2. Instalar dependencias: `pip install -r requirements.txt`
3. Ejecutar el script de cada sección desde su carpeta, por ejemplo:
   ```
   cd S3
   python FIA_G172_Estrada_S3.py
   ```
   Las figuras y el archivo `resultados_S*.json` se crean en `figuras/`.

Todos los experimentos usan semillas fijas, por lo que los resultados son reproducibles.
(Los tiempos en milisegundos de la sección 4 dependen del equipo.)

## Uso de IA

Se usó Claude (Anthropic) para redactar borradores del reporte y del código; la declaración
completa aparece al final de cada PDF.
